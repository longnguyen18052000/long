/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package book;
import java.util.Scanner;

/**
 *
 * @author T460
 */
public abstract class Book {
    private String bookCode,publish ;
    private double unitPrice;
    private int amount;
    Scanner scanner = new Scanner(System.in);

    public Book() {
    }

    public Book(String bookCode, String publish, double unitPrice, int amount) {
        this.bookCode = bookCode;
        this.publish = publish;
        this.unitPrice = unitPrice;
        this.amount = amount;
        
    }

    public String getBookCode() {
        return bookCode;
    }

    public void setBookCode(String BookCode) {
        this.bookCode = BookCode;
    }

    public String getPublish() {
        return publish;
    }

    public void setPublish(String publish) {
        this.publish = publish;
    }

    public double getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(double unitPrice) {
        this.unitPrice = unitPrice;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }
    
    
   public void Import(){
       bookCode = scanner.
   }
    
}
